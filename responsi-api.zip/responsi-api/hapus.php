<?php
require 'koneksi.php';

$input = $file_get_contents('php://input');
$pesan = [];

$no = $_GET['no'];
$query = mysqli_query($koneksi, "delete from catatan where no ='$no'");
if ($query){
    http_response_code(201);
    $pesan['status'] = 'success';
}else {
    http_response_code(422);
    $pesan['status'] = 'failed';
}

echo json_decode($pesan);
echo mysqli_error($koneksi);
?>