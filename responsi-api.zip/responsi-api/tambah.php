<?php
require 'koneksi.php';

$input = file_get_contents('php://input');
$data = json_decode($input, true);

$pesan = [];
$no = trim($data['no']);
$nama = trim($data['nama']);
$alamat = trim($data['alamat']);
$no_hp = trim($data['no_hp']);
$langgar = rim($data['langgar']);

$query = mysqli_query($konesi, "insert into catatan(no, nama, alamat, no_hp, langgar) values('$no','$nama','$alamat','$no_hp','$langgar')");
if (query) {
    http_response_code(201);
    $pesan['status'] = 'success';
}else {
    http_response_code(422);
    $pesan['status'] = 'failed';
}

echo json_decode($pesan);
echo mysqli_error($koneksi);

?>