<?php
require 'koneksi.php';

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$pesan = [];
$no = $data['no'];
$nama = $data['nama'];
$alamat = $data['alamat'];
$no_hp = $data['no_hp'];
$langgar = $data['langgar'];

$query = mysqli_query($koneksi, "update catatan set nama='$nama', alamat='$alamat', no_hp='$no_hp', langgar='$langgar'
where no='$no'");

if ($query){
    http_response_code(201);
    $pesan['status'] = 'success';
}else {
    http_response_code(422);
    $pesan['status'] = 'failed';
}

echo json_decode($pesan);
echo mysqli_error($koneksi);

?>