<?php
require 'koneksi.php';
$data =[];
$no = $_GET['no'];
$query = mysqli_query($koneksi, "select * from catatan where no = '$no'");
$jumlah = mysqli_num_rows($query);
if($jumlah == 1) {
    $row = mysqli_fetch_object($query);
    $data = $row;
}

echo json_decode($data);
echo mysqli_error($koneksi);
?>